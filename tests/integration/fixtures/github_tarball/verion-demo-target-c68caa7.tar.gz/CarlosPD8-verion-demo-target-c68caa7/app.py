"""Intentionally vulnerable Flask application. Scan target only -- never deploy."""

from flask import Flask, render_template, request
import urllib3

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html", urllib3_version=urllib3.__version__)


@app.route("/calculate")
def calculate():
    # DELIBERATE VULNERABILITY: eval() on an unsanitised query-string
    # parameter. This is the single sink this repository exists to expose,
    # and it is the SAST half of the SAST-DAST correlation anchor.
    #
    # The consuming scanner runs a pinned single-rule Semgrep ruleset whose
    # rule id is "dangerous-eval" (pattern: eval(...)). This call must stay
    # visible to that rule: do not fix it, wrap it, rename it, reach it
    # through an alias or getattr, or add a "# nosec" / "# noqa" comment.
    # If "dangerous-eval" stops firing, SAST contributes nothing and the
    # correlation anchor does not exist.
    expr = request.args.get("expr", "")
    try:
        result = eval(expr)
    except Exception as exc:
        result = f"error: {exc}"
    return render_template("result.html", expr=expr, result=result)


if __name__ == "__main__":
    # host="0.0.0.0" so a DAST scanner in a container can reach the host.
    # This also means the app is reachable from the local network -- run it
    # only for the duration of a scan. See README.md.
    #
    # debug=False on purpose: the Werkzeug debug console is a second, separate
    # RCE, and this repo is specified to carry exactly one deliberate code vuln.
    app.run(host="0.0.0.0", port=8080, debug=False)
