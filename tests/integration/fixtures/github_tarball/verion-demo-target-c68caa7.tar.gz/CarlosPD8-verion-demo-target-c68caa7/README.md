# ⚠️ INTENTIONALLY VULNERABLE — DO NOT DEPLOY. This is a security scan target, not an application.

**Read this before running anything.**

- This application contains deliberate, working security vulnerabilities. They
  are the product, not defects. Do not report them; do not fix them.
- Never deploy this anywhere reachable. Not to a server, not to a cloud
  account, not behind a "temporary" tunnel.
- **Binding to `0.0.0.0` means this intentionally vulnerable app is reachable
  from anywhere on the local network while it is running. Run it only for the
  duration of a scan, never on an untrusted network, and never leave it
  running.**
- `/calculate?expr=` is remote code execution by design. Anyone who can reach
  port 8080 can run arbitrary Python as your user.

---

## What this repo is

A scan target. Its only job is to be read by three security tools from **one
checkout** so their findings can be correlated against a single artifact:

| Tool | Reads | Finds |
|---|---|---|
| SAST | the Python source, as files | the `eval()` call site in `app.py` |
| SCA | `requirements.txt`, as files | the pinned vulnerable dependencies |
| DAST | the running app, over HTTP | the `expr` parameter on `/calculate` |

The `eval()` sink is deliberately visible to **both** SAST and DAST — SAST
reports the call site, DAST reports the parameter name. That overlap is the
correlation anchor the repo exists to provide.

**This repo is frozen.** Captured scanner output is pinned to a commit SHA.
Changing a dependency version, the port, or the index page's link silently
invalidates every capture taken against an earlier commit. See
[Frozen — do not modify](#frozen--do-not-modify).

## Contents

| File | Purpose |
|---|---|
| `app.py` | Two routes: the index, and the vulnerable `/calculate` |
| `requirements.txt` | Full pinned transitive dependency closure |
| `README.md` | This file |
| `.gitignore` | Standard Python ignores |
| `templates/index.html` | Crawl entry point — carries the link to the sink |
| `templates/result.html` | Renders the `eval()` result |

No CI, no tests, no linter config, no Docker, and no database — by design.
There is nothing here to verify; the repo is a measuring stick, not a project.

## How to run

```
pip install -r requirements.txt
python app.py
```

Serves on **`http://0.0.0.0:8080/`** — reachable at `http://127.0.0.1:8080/`
locally, and at the host's LAN address from a scanner container.

No environment variables, no config file, no database, no Docker. Developed and
verified on Python 3.11.5.

The port is part of what captured scanner output records. **Changing it changes
the capture** — a DAST result captured against `:8080` does not describe an app
served on any other port.

## Deliberate vulnerabilities

### 1. `eval()` on a query-string parameter — the SAST↔DAST anchor

`GET /calculate?expr=<python>` passes the `expr` query parameter straight to
`eval()` with no validation. ([`app.py`](app.py))

```
curl "http://127.0.0.1:8080/calculate?expr=2*3"                      # -> 6
curl "http://127.0.0.1:8080/calculate?expr=__import__('os').getcwd()"  # -> RCE
```

**Why it is here.** It is the one finding both SAST and DAST can see. DAST
reports the parameter name `expr`; SAST reports the `eval` call site. Correlating
those two reports against one artifact is the whole point of the repo.

It is reached over **GET** with a **query-string** parameter specifically because
that is what a DAST scanner reports, and the parameter name is half of what makes
the finding correlatable.

The route is linked from the index page with a real example query string
(`?expr=2*3`). That link is load-bearing — a baseline DAST crawl starts at `/`
and follows `<a href>` links, so removing it makes the vulnerability
undiscoverable and the repo useless. `templates/index.html` carries an HTML
comment explaining this; read it before touching that file.

Deliberately *not* included, to keep the finding set minimal and stable:
`debug=True` (a second, separate RCE via the Werkzeug console), template
injection, and XSS (Jinja autoescaping is left on).

### 2. Pinned vulnerable dependencies — the SCA anchor

`requirements.txt` pins the full transitive runtime closure at exact `==`
versions. At the time of capture, `pip-audit` reported **22 known
vulnerabilities across 3 packages**:

| Package | Version | Findings | Notable |
|---|---|---|---|
| `urllib3` | 1.24.1 | 14 | CRLF injection, ReDoS, cookie and proxy-auth header leaks on cross-origin redirect, request body retained on 303 |
| `Werkzeug` | 2.3.8 | 6 | debugger RCE, `safe_join` path traversal on Windows, multipart resource exhaustion |
| `Flask` | 2.3.1 | 2 | **CVE-2023-30861** (PYSEC-2023-62) |

Reproduce the list with `pip-audit -r requirements.txt` — do not trust a CVE
list transcribed into prose, including this one.

**Why Flask 2.3.1 specifically.** It is the *newest* Flask release still carrying
CVE-2023-30861 (session cookie disclosure: a proxy-cached response carrying
`Vary: Cookie` can be served to another client along with the first client's
`Set-Cookie`). Picking the newest vulnerable release rather than the oldest gives
maximum runtime compatibility with modern Python while still producing a recent,
high-severity finding that every SCA database indexes.

**Why `urllib3` is imported.** Every line in `requirements.txt` is a genuine
dependency of the code, so the app actually imports `urllib3` and displays
`urllib3.__version__` on the index page. Reading `__version__` is the most inert
possible use — no network call, so no SSRF and no unintended second vulnerability.

**Why the whole closure is pinned.** Transitive dependencies are real
dependencies — the app does not start without Werkzeug. Pinning them all means
`pip install -r requirements.txt` resolves to the same set that the captured
scan was taken against. Their own CVEs are a benefit here, not a cost: this repo
exists to produce a *stable* finding set, not a small one.

Note that Werkzeug's debugger RCE (fixed in 3.0.3) is reported by SCA on version
grounds but is **not** reachable in this app, because `app.run()` sets
`debug=False`. That mismatch between a version-based SCA finding and actual
reachability is realistic, and is left in place deliberately.

## Frozen — do not modify

After the initial commit, treat every file here as immutable. Captured scanner
output is pinned to a commit SHA, and these changes silently invalidate it:

- **Do not update dependencies.** Not the pins, not the closure. There is no
  Dependabot here on purpose.
- **Do not remove or edit the link in `templates/index.html`.** It is the only
  path a crawler has from `/` to the vulnerable route, and its `?expr=2*3` query
  string is what gives the crawler a parameter to fuzz.
- **Do not change the port** from 8080.
- **Do not "clean up" `app.py`.** No input validation, no `# nosec` or `# noqa`
  comment, no renaming or aliasing the `eval` call.

If any of the above must change, the correct procedure is to change it, commit,
and **re-capture all three scans against the new SHA** — never to change it and
keep the old captures.
